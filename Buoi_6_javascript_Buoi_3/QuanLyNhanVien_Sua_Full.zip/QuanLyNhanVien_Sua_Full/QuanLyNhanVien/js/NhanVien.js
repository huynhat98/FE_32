function NhanVien(_maNV, _hoTen, _email, _password, _date, _chucVu) {
  this.maNV = _maNV;
  this.hoTen = _hoTen;
  this.email = _email;
  this.password = _password;
  this.date = _date;
  this.chucVu = _chucVu;
}
