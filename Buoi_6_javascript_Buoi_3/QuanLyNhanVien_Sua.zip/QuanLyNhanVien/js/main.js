var danhSachNhanVien = new DanhSachNhanVien();
var validation = new Validation();

getEle("btnThem").addEventListener("click", function() {
  getEle("btnCapNhat").style.display = "none";
});

getEle("btnThemNV").addEventListener("click", function() {
  var maNV = getEle("msnv").value;
  var hoTen = getEle("name").value;
  var email = getEle("email").value;
  var password = getEle("password").value;
  var date = getEle("datepicker").value;
  var chucVu = getEle("chucvu").value;

  var isValid = true;

  /* MaNV */
  isValid &= validation.kiemTraRong(maNV, "tbMaNV", "(*) MaNV không được rỗng");

  /* HoTen */
  isValid &=
    validation.kiemTraRong(hoTen, "tbTen", "(*) Họ tên không được rỗng") &&
    validation.kiemTraChuoi(hoTen, "tbTen", "(*) Vui lòng nhập vào chuỗi!");

  /* Email */
  isValid &=
    validation.kiemTraRong(email, "tbEmail", "(*) Email không được rỗng") &&
    validation.checkEmail(email, "tbEmail", "(*) Email không đúng định dạng");

  /* Password */
  isValid &=
    validation.kiemTraRong(
      password,
      "tbMatKhau",
      "(*) Password không được rỗng"
    ) &&
    validation.kiemTraDoDaiKyTu(
      password,
      "tbMatKhau",
      "(*) Ky tu 6 - 12",
      6,
      12
    );

  /* Chuc Vu */
  isValid &= validation.kiemTraChucVu(
    "chucvu",
    "tbChucVu",
    "(*) Vui lòng chọn chức vụ"
  );

  if (isValid) {
    var nhanVien = new NhanVien(maNV, hoTen, email, password, date, chucVu);
    danhSachNhanVien.themNhanVien(nhanVien);
    taoBang();
  }
});

function taoBang() {
  //-------------- String Template
  /**
  var name2 = "cybersoft";
  var result2 = `Hello ${name2}` // => Hello cybersoft
    */

  var tbody = getEle("tableDanhSach");
  var content = "";
  danhSachNhanVien.mangNhanVien.map(function(item, index) {
    content += `
        <tr>
            <td>${item.maNV}</td>
            <td>${item.hoTen}</td>
            <td>${item.email}</td>
            <td>${item.date}</td>
            <td>${item.chucVu}</td>
        </tr>
      `;
  });
  tbody.innerHTML = content;
}

function getEle(id) {
  return document.getElementById(id);
}
