let a = 10;
let b = 20;

let total = a + b;

function tinhTong() {
  return a + b;
}

function tinhHieu() {
  return b - a;
}

export { total, tinhTong, tinhHieu };
// export default total;
